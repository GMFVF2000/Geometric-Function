//
// Created by abou on 18/11/2019.
//

#include "MyPolygon.h"

MyPolygon::MyPolygon(const std::vector<Vector2D> &myPoints) : myPoints(myPoints) {}

void MyPolygon::addVector2D(Vector2D item) {

}
