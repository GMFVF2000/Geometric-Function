//
// Created by abou on 18/11/2019.
//

#ifndef RECTANGLES_VECTOR2D_H
#define RECTANGLES_VECTOR2D_H


class Vector2D {
private :float p_x;
         float p_y;
public:
    Vector2D(float pX, float pY);

    Vector2D();
};



#endif //RECTANGLES_VECTOR2D_H
