#include <iostream>
#include <cstdlib>
#include <glutWindow.h>
#include "MyPolygon.h"

using namespace std;

class PolygonDraw: public GlutWindow {
    int value=10;
    bool isOverBox1,isOverBox2;
    MyPolygon *S1, *S2, *S3;

public:
    PolygonDraw(const string &title,int argc,char **argv):GlutWindow(argc,argv,title,800,100) {};
public:
    void loadVector2D() {
        std::vector<Vector2D> *s1Vector = new std::vector<Vector2D>();
        //s1Vector->insert(new Vector2D())
    };

    void onStart() override;
    void onDraw() override;
    void onQuit() override;
    void onMouseMove(double cx,double cy) override;
    void onMouseDown(int button,double cx,double cy) override;
};

void PolygonDraw::onStart() {
    cout << "Start..."  << endl;
    glClearColor(0.25,0.25,0.25,1.0);
}

void PolygonDraw::onQuit() {
    cout << "The end."  << endl;
}

void PolygonDraw::onDraw() {
    glPushMatrix();


    glPopMatrix();
}

void PolygonDraw::onMouseMove(double cx,double cy) {
    isOverBox1 = isInRect(cx,cy,0.05,0.05,0.25,0.9);
    isOverBox2 = isInRect(cx,cy,0.7,0.05,0.25,0.9);
}

void PolygonDraw::onMouseDown(int button, double cx, double cy) {
    if (isOverBox1) {
        value--;
    } else if (isOverBox2) {
        value++;
    }

}

int main(int argc,char **argv) {
    PolygonDraw ex("Rectangles", argc,argv);
    ex.start();
    return 0;
}

