//
// Created by abou on 18/11/2019.
//

#include "Vector2D.h"

Vector2D::Vector2D(float pX, float pY) : p_x(pX), p_y(pY) {

}

Vector2D::Vector2D() {

}
