//
// Created by abou on 18/11/2019.
//

#ifndef RECTANGLES_MYPOLYGON_H
#define RECTANGLES_MYPOLYGON_H


#include <vector>
#include "Vector2D.h"

class MyPolygon {
public:
    MyPolygon(const std::vector<Vector2D> &myPoints);
    void addVector2D(Vector2D item);
private:

    std::vector<Vector2D> myPoints;


};


#endif //RECTANGLES_MYPOLYGON_H
