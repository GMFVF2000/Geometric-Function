#include "PolygonDraw.h"


int main(int argc,char **argv) {
    PolygonDraw ex("Polydron", argc,argv);
    ex.start();


    return 0;
}

