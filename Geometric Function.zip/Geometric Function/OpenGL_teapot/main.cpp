/*********************************************************/
/* Benoit Piranda          Université de Franche-Comté   */
/* M1 IOT Copyright 2019                                 */
/*********************************************************/
#ifdef _WIN32
#include <windows.h>
#endif
#include <iostream>
#include <string>
#include <GL/freeglut.h>
#include <math.h>
#include <array>

using namespace std;

/*********************************************************/
/* prototypes                                            */
static void initGL();
static void reshapeFunc(int,int);
static void drawFunc();
static void kbdFunc(unsigned char,int,int);
static void mouseFunc(int button,int state,int x,int y);
static void motionFunc(int x,int y);
static void idleFunc();
static void quit();
static void myCylinder(float raduis, float height, int subR, int subH);


/*********************************************************/
/* global variables                                      */
int width=1024,height=800; // initial size of the screen
const float cameraPos[] = {5.0f,2.0f,8.0f};
float cameraTheta=0.0f, cameraPhi=0.0f, cameraDist=5.0f; // spherical coordinates of the point of view
float rotationAngle=0; // rotation angle of the teapot /z
int mouseX0,mouseY0;

int main(int argc, char** argv) {
    glutInit(&argc, argv);

    initGL();
//	glutFullScreen();
//  glutSetCursor(GLUT_CURSOR_NONE); // allow to hide cursor

    /* bind reshape function */
    glutReshapeFunc(reshapeFunc);
    /* bind drawing function */
    glutDisplayFunc(drawFunc);
    /* bind mouse click function */
    glutMouseFunc(mouseFunc);
    /* bind mouse motion function */
    glutMotionFunc(motionFunc); // drag
    //glutPassiveMotionFunc(passiveMotionFunc);
    /* bind key pressed function */
    glutKeyboardFunc(kbdFunc);
    /* bind special key pressed function */
//  glutSpecialFunc(kbdSpecialFunc);
    /* bind idle function */
    glutIdleFunc(idleFunc);
    /* bind close function */
    glutCloseFunc(quit);

    glutMainLoop();

    return 0;
}

/*********************************************************/
/* frame drawing function                                */
static void drawFunc(void) {
    static GLfloat red[4] = { 1.0f, 0.0f, 0.0f, 1.0f}; // red color material
    static GLfloat green[4] = { 0.0f, 1.0f, 0.0f, 1.0f}; // red color material
    static GLfloat blue[4] = { 0.0f, 0.0f, 1.0f, 1.0f}; // red color material
    static GLfloat grey[4] = { 0.8f, 0.8f, 0.8f, 1.0f}; // red color material
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glPushMatrix();

   //when you move the mouse you will change cameraTheta and cameraPhi
    double x = cameraDist*cos(cameraTheta)*cos(cameraPhi);
    double y  = cameraDist*sin(cameraTheta)*cos(cameraPhi);
    double z = cameraDist*sin(cameraPhi);

   // (x,y,z) : camera position, (0,0,0) target point , target point (0,0,1)  verrtical vector

    gluLookAt(x,y,z,0,0,0,0,0,1.0);

    GLfloat pos[4] = { 0.0f, 0.0f, 5.0f, 1.0f}; // position
    glLightfv(GL_LIGHT0, GL_POSITION, pos );
//construct the tree axis on my scheme
    glPushMatrix();
   // pour le bleu
    glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,blue);
    glutSolidCylinder(0.02,2.0,20,5);
   glPushMatrix();
    glRotatef(-90.0,1,0,0);
    glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,green);
    glutSolidCylinder(0.02,2.0,20,5);
    myCylinder(0.5,2,20,1);

    glPopMatrix();
    glRotatef(90.0,0,1,0);
    glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,red);
    glutSolidCylinder(0.02,2.0,20,5);


    glPopMatrix();
    glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,grey);
    glPushMatrix();

   //il troune car ce angle chaque à interval de temps regulier
    glPushMatrix();

    glTranslated(1.0,0.0,2.0); //  position of the rotation axis
    glRotatef(rotationAngle,0.0f,0.0f,1.0f); //rotation around the axis
    glTranslated(2.0,0.0,2.0); //

    glRotatef(-rotationAngle,2.0f,0.0f,0.0f); //turn the object arrount itself

    glRotatef(90.0,1.0f,0.0f,0.0f); // orientation of the teapot (along z)
    glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,grey);
    glutSolidTeapot(0.5);
    glutSolidCylinder(0.4,0.5,10,10);
    glPopMatrix();
    glutSwapBuffers();
}

/*********************************************************/
/* Window size update function                           */
/* width: width of the drawing area                      */
/* height: width of the drawing area                     */
static void reshapeFunc(int w,int h) {
    width=w;
    height=h;
    glViewport(0,0,width,height);
    // initialize Projection matrix
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(30.0,(double)width/(double)height,0.1,100.0);
    // initialize ModelView matrix
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

/*********************************************************/
/* Animation function                                    */
static void idleFunc(void) {
    static int initTime = glutGet(GLUT_ELAPSED_TIME); // ms
    int currentTime = glutGet(GLUT_ELAPSED_TIME);

    double dt=(currentTime-initTime)/1000.0;

//	sprintf_s(chaineFPS,"FR : %lf",1.0/dt);
    initTime = currentTime;

    rotationAngle += dt*20.0; // turn at 20� / s

    glutPostRedisplay();
}

/*********************************************************/
/* Key pressed function                                  */
/* c: key pressed character                              */
/* x,y: mouse coordinates                                */
static void kbdFunc(unsigned char c, int x, int y) {
    switch(c) {
        case 27: case 'q' : // quit
            glutLeaveMainLoop();
            break;
        case 'f' :
            glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
            break;
        case 'F' :
            glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
            break;
        case '+' :
            cameraDist+=0.10;
            break;
        case '-' :
            cameraDist-=0.10;
            break;
    }
    glutPostRedisplay();
}

/*********************************************************/
/* Mouse clicked function                                */
/* button: sum of pressed buttons id                     */
/* state: action                                         */
/* x,y: mouse coordinates                                */
static void mouseFunc(int button,int state,int x,int y) {
    mouseX0=x;
    mouseY0=y;
}

/*********************************************************/
/* Mouse move function (with button pressed)             */
/* x,y: mouse coordinates                                */
static void motionFunc(int x,int y) {
    cameraTheta += (x-mouseX0)*0.01;
    cameraPhi += (y-mouseY0)*0.01;

    mouseX0=x;
    mouseY0=y;
}

/*********************************************************/
/* Initialisation of the OPENGL window and parameters    */
static void initGL() {
    // create the window
    glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
    glutInitWindowPosition(0, 0);
    glutInitWindowSize(width,height);
    glutCreateWindow("Master IOT");

    glEnable(GL_DEPTH_TEST);
    glShadeModel(GL_SMOOTH);
    glEnable(GL_NORMALIZE); // auto-normalize normal vectors

    glClearColor(0.0,0.0,0.0,0.0); // background color

    glEnable(GL_LIGHTING);
    /* LIGHT0 light source parameters */
    GLfloat pos[4] = { 0.0f, 0.0f, 5.0f, 1.0f}; // position
    GLfloat light_diffuse[4] = {1.0, 1.0, 1.0, 1.0}; // colors
    GLfloat light_ambient[4] = {0.2, 0.2, 0.2, 1.0};

    glEnable(GL_LIGHT0);
    glLightfv(GL_LIGHT0, GL_POSITION, pos );
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_diffuse);
}

static void quit() {

}

/**
 *
 * @param raduis
 * @param height
 * @param subR
 * @param subH
 */
static void myCylinder(float raduis, float height, int subR, int subH){
    float *tabVertices;

   // std::array<float> test;
    //x_i = radius * cos(2 * i * M_PI/subR)
    //y_i = radius * sin(2 * i * M_PI/subR)
    //z_i = height
    glNormal3f(0,0,1.0f);
    glBegin(GL_POLYGON);
    float a;
    for( int i = 0; i<subR;i++){
        a= 2.0*i*M_PI/subR;
        glVertex3d(raduis*cos(a),raduis*sin(a),height);



    }
    glEnd();




    //boyyom disk

    //x_i = radius * cos(-2 * i * M_PI/subR)
    //y_i = radius * sin(-2 * i * M_PI/subR)
    //z_i = height
    glNormal3f(0,0,-1.0f);
    glBegin(GL_POLYGON);

    for( int i = 0; i<subR;i++){
        a= -2.0*i*M_PI/subR;
        glVertex3d(raduis*cos(a),raduis*sin(a),0);
    }
    glEnd();



    double cs,sn,

    glBegin(GL_QUAD_STRIP);
    for (int j = 0; j <subR+1 ; ++j) {
        a = - 2.0*j*M_PI/subR;
        cs= cos(a);
        sn = sin(a);

        glNormal3f(cs,sn,0);
        glVertex3f(raduis*cs,raduis*sn,0);
        glVertex3f(raduis*cs,raduis*sn,height);

    }
    glEnd();
}