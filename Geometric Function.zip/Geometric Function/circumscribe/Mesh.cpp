//
// Created by abou on 02/12/2019.
//

#include "Mesh.h"

Mesh::Mesh(float vect[] [2], int nbrVEct, int triangleArg[][3], int nbrTri) {
    for (int i = 0; i <nbrVEct ; ++i) {
        vertices.push_back(Vector2D(vect[i][0],vect[i][0]));
    }

    for (int i = 0; i <nbrTri ; ++i) {
        triangles.push_back(Triangle( &vertices.at(triangleArg[i][0]), &vertices.at(triangleArg[i][1]), &vertices.at(triangleArg[i][2])));
           }

}

Mesh::Mesh() {
    float tabVect[][2] ={{280 , 740},{700 , 750},{500 , 700},{900 , 720},{50 , 410},{340 , 400},{650 , 390},{950 , 300},{400 , 200},{550 , 190},{200 , 50},{800 , 100}};
    int   tabTri[ ] [ 3 ] ={{0 , 2 , 1},{0 , 4 , 2},{1 , 6 , 3},{2 , 5 , 8},{2 , 6 , 1},{2 , 8 , 6},{3 , 6 , 11},{3 , 11 , 7},{4 , 5 , 2},{4 , 8 , 5},{4 , 10 , 8},{6 , 8 , 9},{6 , 9 , 11},{8 , 10 , 9},{9 , 10 , 11}};
    Mesh ( tabVect , 12 , tabTri , 15 ) ;


}

void Mesh::checkDelaunay() {
    auto t = triangles.begin();


    while (t != triangles.end()) {
        t++;


    }
}
void Mesh::draw(){
    for (auto &item: triangles) {
        item.draw();
    }
}

//void Mesh::solve(){










