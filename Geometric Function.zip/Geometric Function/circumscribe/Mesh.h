//
// Created by abou on 02/12/2019.
//

#ifndef CIRCUMSCRIBE_MESH_H
#define CIRCUMSCRIBE_MESH_H


#include <vector>
#include "Vector2D.h"
#include "Triangle.h"

class Mesh {

    std::vector<Vector2D>vertices;
    std::vector<Triangle> triangles;
public:
    Mesh();
    Mesh(float vect[] [2], int nbrVEct, int triangle[][3], int nbrTri);

    bool checkDelaunay();

    void draw();
};


#endif //CIRCUMSCRIBE_MESH_H
